const form = document.getElementById("chatForm");
const promptInput = document.getElementById("prompt");
const messagesEl = document.getElementById("messages");
const welcome = document.getElementById("welcome");
const sendButton = document.getElementById("sendButton");
const toastEl = document.getElementById("toast");
const history = [];
let busy = false;
let toastTimer;

function toast(message) {
  toastEl.textContent = message;
  toastEl.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toastEl.classList.remove("show"), 2600);
}
function addMessage(role, text, isError = false) {
  welcome.hidden = true;
  const row = document.createElement("div");
  row.className = `message ${role === "user" ? "user" : "assistant"}`;
  const avatar = document.createElement("div");
  avatar.className = "message-avatar";
  avatar.textContent = role === "user" ? "Я" : "✦";
  const bubble = document.createElement("div");
  bubble.className = "bubble" + (isError ? " error" : "");
  bubble.textContent = text;
  row.append(avatar, bubble);
  messagesEl.appendChild(row);
  document.getElementById("conversation").scrollTop = document.getElementById("conversation").scrollHeight;
  return bubble;
}
async function sendMessage(text) {
  text = text.trim();
  if (!text || busy) return;
  busy = true;
  sendButton.disabled = true;
  promptInput.value = "";
  promptInput.style.height = "34px";
  addMessage("user", text);
  history.push({ role: "user", text });
  const typing = addMessage("model", "Dron AI думает…");
  typing.classList.add("typing");
  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ messages: history })
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || `Ошибка сервера (${response.status})`);
    typing.classList.remove("typing");
    typing.textContent = data.answer;
    history.push({ role: "model", text: data.answer });
  } catch (error) {
    typing.classList.add("error");
    typing.classList.remove("typing");
    typing.textContent = error.message || "Не удалось получить ответ. Попробуй ещё раз.";
    history.pop();
  } finally {
    busy = false;
    sendButton.disabled = false;
    promptInput.focus();
    document.getElementById("conversation").scrollTop = document.getElementById("conversation").scrollHeight;
  }
}
form.addEventListener("submit", (event) => {
  event.preventDefault();
  sendMessage(promptInput.value);
});
promptInput.addEventListener("input", () => {
  promptInput.style.height = "34px";
  promptInput.style.height = Math.min(promptInput.scrollHeight, 150) + "px";
});
promptInput.addEventListener("keydown", (event) => {
  if (event.key === "Enter" && !event.shiftKey) {
    event.preventDefault();
    form.requestSubmit();
  }
});
document.querySelectorAll("[data-prompt]").forEach((button) => {
  button.addEventListener("click", () => sendMessage(button.dataset.prompt));
});
document.getElementById("newChat").addEventListener("click", () => {
  history.length = 0;
  messagesEl.replaceChildren();
  welcome.hidden = false;
  document.getElementById("sidebar").classList.remove("open");
  promptInput.focus();
});
["plansButton", "upgradeButton", "topPlans"].forEach((id) => {
  document.getElementById(id).addEventListener("click", () => toast("Экран подписок подключим следующим этапом."));
});
document.getElementById("menuButton").addEventListener("click", () => {
  document.getElementById("sidebar").classList.toggle("open");
});
fetch("/api/status").then((r) => r.json()).then((status) => {
  if (!status.configured) toast("Добавь API-ключ в .env, чтобы включить ИИ.");
}).catch(() => {});
