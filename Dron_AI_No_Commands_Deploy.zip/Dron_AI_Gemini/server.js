require("dotenv").config();
const express = require("express");
const path = require("path");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const API_KEY = process.env.GEMINI_API_KEY;
const MODEL = process.env.GEMINI_MODEL || "gemini-3.5-flash";

app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/status", (_req, res) => {
  res.json({ ok: true, configured: Boolean(API_KEY && API_KEY !== "PASTE_YOUR_KEY_HERE") });
});

app.post("/api/chat", async (req, res) => {
  if (!API_KEY || API_KEY === "PASTE_YOUR_KEY_HERE") {
    return res.status(503).json({ error: "Сначала добавь Gemini API-ключ в файл .env и перезапусти Dron AI." });
  }

  const messages = req.body && req.body.messages;
  if (!Array.isArray(messages) || messages.length === 0) {
    return res.status(400).json({ error: "Напиши сообщение, чтобы начать чат." });
  }

  // Only accept the roles and text we need; never accept a key from the browser.
  const contents = messages.slice(-80).map((m) => ({
    role: m.role === "model" ? "model" : "user",
    parts: [{ text: String(m.text || "").slice(0, 12000) }]
  })).filter((m) => m.parts[0].text.trim().length > 0);

  if (!contents.length) {
    return res.status(400).json({ error: "Сообщение пустое." });
  }

  try {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(MODEL)}:generateContent`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-goog-api-key": API_KEY
        },
        body: JSON.stringify({
          systemInstruction: {
            parts: [{ text: "Ты Dron AI — дружелюбный, полезный ИИ-помощник. Отвечай на языке пользователя, понятно и по делу." }]
          },
          contents,
          generationConfig: { temperature: 0.8, maxOutputTokens: 2048 }
        })
      }
    );

    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      const googleMessage = data?.error?.message || `Gemini API вернул ошибку (${response.status}).`;
      return res.status(response.status >= 500 ? 502 : response.status).json({
        error: `Ошибка Gemini: ${googleMessage}`
      });
    }

    const answer = (data.candidates?.[0]?.content?.parts || [])
      .map((part) => part.text || "")
      .join("")
      .trim();

    if (!answer) {
      return res.status(502).json({ error: "Gemini не вернул текст. Попробуй задать вопрос ещё раз." });
    }

    res.json({ answer, model: MODEL });
  } catch (_error) {
    res.status(502).json({ error: "Не удалось подключиться к Gemini. Проверь интернет и попробуй ещё раз." });
  }
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Dron AI открыт: http://localhost:${PORT}`);
  console.log(`Модель: ${MODEL}`);
  console.log(`Gemini API-ключ: ${API_KEY && API_KEY !== "PASTE_YOUR_KEY_HERE" ? "найден" : "не настроен — см. SETUP.txt"}`);
});
