# Dron AI

Dron AI is a Node.js + Express web app with a server-side Google Gemini API connection.

## Deploy without using a terminal

1. Extract this ZIP on your computer.
2. Create a **private** repository on GitHub.
3. Upload the *contents* of the `Dron_AI_Gemini` folder into the repository root (not the outer folder).
4. In Render, create a new Blueprint and connect the repository. Render will read `render.yaml`.
5. When asked, add `GEMINI_API_KEY` in Render's environment settings. Never put the key in source files or commit a `.env` file.
6. Wait for deployment and open the generated `onrender.com` URL.

The Render service uses the free plan, which may sleep after inactivity. Google Gemini API usage may have quotas or costs depending on the account and model.

Local Windows instructions are in `SETUP.txt`.
